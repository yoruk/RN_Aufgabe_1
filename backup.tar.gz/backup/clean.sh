#!/bin/sh

rm aufgabe_1
rm src/*.o
