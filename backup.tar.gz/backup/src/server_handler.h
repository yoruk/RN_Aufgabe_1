#ifndef SERVERHANDLER_H_
#define SERVERHANDLER_H_

void setPort_Server(char port[]);
void* server_handler(void* arg);

#endif /* SERVERHANDLER_H_ */
