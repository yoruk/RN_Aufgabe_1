#ifndef SERVER_H_
#define SERVER_H_

void* server(void* new_sockfd);

#endif /* SERVER_H_ */
