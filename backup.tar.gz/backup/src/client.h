#ifndef CLIENT_H_
#define CLIENT_H_

void setHostname(char hostname[]);
void setPort_Client(char port[]);
void* client(void* arg);

#endif /* CLIENT_H_ */
